package sr.unasat.retailShop.entities;


import javax.persistence.*;
import java.time.LocalDate;
import java.util.Date;
import lombok.*;


@Entity
public class Employees {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    @Column(name = "employee_id")
    private long id;
    private String voornaam;
    private String achternaam;
    private Date geboortedatum;
    private String salaris;
    private String functie;


    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getVoornaam() {
        return voornaam;
    }

    public void setVoornaam(String voornaam) {
        this.voornaam = voornaam;
    }

    public String getAchternaam() {
        return achternaam;
    }

    public void setAchternaam(String achternaam) {
        this.achternaam = achternaam;
    }

    public Date getGeboortedatum() {
        return geboortedatum;
    }

    public void setGeboortedatum(Date geboortedatum) {
        this.geboortedatum = geboortedatum;
    }

    public String getSalaris() {
        return salaris;
    }

    public void setSalaris(String salaris) {
        this.salaris = salaris;
    }

    public String getFunctie() {
        return functie;
    }

    public void setFunctie(String functie) {
        this.functie = functie;
    }



//    public static void builder(String voornaam, String achternaam, Date geboortedatum, String salaris, String functie ) {
//        Stream.Builder<String> builder = Stream.builder();
//        builder.add("TEST");
//        Stream<String> str = builder.build();
//        str.forEach(System.out::println);
//    }

    @Override
    public String toString() {
        return "Employees{" +
                "id=" + id +
                ", voornaam='" + voornaam + '\'' +
                ", achternaam='" + achternaam + '\'' +
                ", geboortedatum=" + geboortedatum +
                ", salaris='" + salaris + '\'' +
                ", functie='" + functie + '\'' +
                '}';
    }
}

