package sr.unasat.retailShop.dao;

import sr.unasat.retailShop.entities.Address;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

public class AdressDao {
    private EntityManager entityManager;

    public AdressDao(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

    public Address findById(String id) {
        entityManager.getTransaction().begin();
        String jpql = "select a from Address a where a.id = :id";
        TypedQuery<Address> query = entityManager.createQuery(jpql, Address.class);
        Address address = query.setParameter("id", id).getSingleResult();
        entityManager.getTransaction().commit();
        return address;
    }

    public Address insert(Address address) {
        entityManager.getTransaction().begin();
        entityManager.persist(address);
        entityManager.getTransaction().commit();
        return address;
    }

    public int updateAddress (Address address) {
        entityManager.getTransaction().begin();
        Query query = entityManager.createQuery("update Address a set a.straatNaam = :straatNaam where a.id = :id");
        query.setParameter("id", address.getId());
        query.setParameter("straatNaam", address.getStraatNaam());
        int rowsupdated = query.executeUpdate();
        System.out.println("entities updated: " + rowsupdated);
        entityManager.getTransaction().commit();
        return rowsupdated;
    }
}
