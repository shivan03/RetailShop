package sr.unasat.retailShop.app;


import sr.unasat.retailShop.config.JpaConfig;

import sr.unasat.retailShop.dao.AdressDao;
import sr.unasat.retailShop.dao.EmployeesDao;

import sr.unasat.retailShop.dao.OrdersDao;
import sr.unasat.retailShop.entities.Address;
import sr.unasat.retailShop.entities.Employees;
import sr.unasat.retailShop.entities.Orders;

import java.time.LocalDate;
import java.util.List;


public class Applicatie {

    public static void main(String[] args) {
        JpaConfig.getEntityManager();
        EmployeesDao employeesDao  = new EmployeesDao(JpaConfig.getEntityManager());

//        delete
//        Employees foundDeletedEmployee = employeesDao.findByVoornaam("Darius");
//        int totalRecordsDeleted = employeesDao.delete("Darius");
//        System.out.println(totalRecordsDeleted);
//        System.out.println(foundDeletedEmployee);
//
//        JpaConfig.shutdown();


//          update
//        AdressDao adressDao = new AdressDao(JpaConfig.getEntityManager());
//

//
//        Address foundAddress = adressDao.findById("1");
//        savedAdress.setAddress(foundAddress.get)





//        OrdersDao ordersDao = new OrdersDao(JpaConfig.getEntityManager());
//        List<Orders> ordersList = ordersDao.retrieveOrdersList();
//        ordersList.stream().forEach(System.out::println);
//        for (Orders orders : ordersList) {
//            System.out.println(orders);
//        }


        //insert
        
        Employees employees = Employees.builder("Mike", "Wazowski", ,"SRD 2000", "manager")/*.voornaam("").achternaam("").geboortedatum("").functie("")*/.build();
        Employees savedEmployees = employeesDao.insert(employees);
        System.out.println(savedEmployees);

    }
}
