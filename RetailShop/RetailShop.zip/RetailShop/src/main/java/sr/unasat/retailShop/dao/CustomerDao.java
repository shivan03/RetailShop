package sr.unasat.retailShop.dao;

import sr.unasat.retailShop.entities.Customer;

import javax.persistence.EntityManager;
import javax.persistence.Query;

public class CustomerDao {
    private EntityManager entityManager;

    public CustomerDao(EntityManager entityManager) {
        this.entityManager = entityManager;
    }

//    public  Customer findById(String id) {
//        entityManager.getTransaction().begin();
//        String jpql = "select c"
//    }

    public Customer insert(Customer customer) {
        entityManager.getTransaction().begin();
        entityManager.persist(customer);
        entityManager.getTransaction().commit();
        return customer;
    }

    //public int delete( )


}
