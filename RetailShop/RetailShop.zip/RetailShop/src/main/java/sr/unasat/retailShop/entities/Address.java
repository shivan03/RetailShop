package sr.unasat.retailShop.entities;


import javax.persistence.*;

@Entity
public class Address {

    @Id
    @GeneratedValue(strategy=GenerationType.AUTO)
    @Column(name = "address_id")
    private Long id;

    @Column(name = "straat_naam")
    private String straatNaam;
    private int nummer;



    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getStraatNaam() {
        return straatNaam;
    }

    public void setStraatNaam(String straatNaam) {
        this.straatNaam = straatNaam;
    }

    public int getNummer() {
        return nummer;
    }

    public void setNummer(int nummer) {
        this.nummer = nummer;
    }


    @Override
    public String toString() {
        return "Address{" +
                "id=" + id +
                ", straatNaam='" + straatNaam + '\'' +
                ", nummer=" + nummer +
                '}';
    }
}
