package sr.unasat.retailShop.entities;

import javax.persistence.*;
import java.time.LocalDate;

@Entity
public class Bill {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    @Column(name = "bon_id")
    private Long id;
    @Column(name = "bon_datum")
    private LocalDate bonDatum;
    @Column(name = "betaald_bedrag")
    private double betaaldBedrag;


    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public LocalDate getBonDatum() {
        return bonDatum;
    }

    public void setBonDatum(LocalDate bonDatum) {
        this.bonDatum = bonDatum;
    }

    public double getBetaaldBedrag() {
        return betaaldBedrag;
    }

    public void setBetaaldBedrag(double betaaldBedrag) {
        this.betaaldBedrag = betaaldBedrag;
    }

    @Override
    public String toString() {
        return "Bill{" +
                "id=" + id +
                ", bonDatum=" + bonDatum +
                ", betaaldBedrag=" + betaaldBedrag +
                '}';
    }
}
